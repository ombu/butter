from fabric.api import env
from fabric.utils import _AttributeDict

env.settings = _AttributeDict()
